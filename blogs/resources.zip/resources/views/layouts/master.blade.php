<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>@yield('title')</title>


    <!-- Favicon -->
    {{-- <link rel="icon" href="{{ asset('assets/images/favicon.png') }}" type="image/x-icon" /> --}}
    <link rel="icon" href="{{ asset('assets/images/stethoscope-solid-full.svg') }}" type="image/x-icon" />

    <!-- -----font awesome---- -->
    {{-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> --}}
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.0/css/all.min.css">
    <link href="{{ asset('assets/css/style.css') }}" rel="stylesheet" />
    <link href="{{ asset('assets/css/blog_style.css') }}" rel="stylesheet" />
    <!-- boostrap -->
    <link href="{{ asset('assets/css/bootstrap.css') }}" rel="stylesheet" />

    <!-- Bootstrap Framework Version 4.5.3 -->
    <link href="{{ asset('assets/css/bootstrap.min.css') }}" type="text/css" rel="stylesheet" />

    <!-- Ion Icons Version 5.1.0 -->
    <link href="{{ asset('assets/css/ionicons.css') }}" type="text/css" rel="stylesheet" />

    <!-- Medical Icons -->
    <link href="{{ asset('assets/css/medwise-icons.css') }}" type="text/css" rel="stylesheet" />

    <!-- Stylesheets -->
    <link href="{{ asset('assets/css/vendors.min.css') }}" type="text/css" rel="stylesheet" />
    <link href="{{ asset('assets/css/style.min.css') }}" type="text/css" rel="stylesheet" id="style" />
    <link href="{{ asset('assets/css/components.min.css') }}" type="text/css" rel="stylesheet" id="components" />

    <!-- Animation css -->
    <link href="{{ asset('assets/css/animate.css') }}" type="text/css" rel="stylesheet" />

    <!-- responsive css -->
    <link href="{{ asset('assets/css/responsive.css') }}" type="text/css" rel="stylesheet" />
    <link href="{{ asset('assets/css/new-contact-form.css') }}" type="text/css" rel="stylesheet" />

    <!-- slick css -->
    <link href="{{ asset('assets/css/slick.css') }}" type="text/css" rel="stylesheet" />
    {{-- <link href="{{ asset('assets/css/style.min.css') }}" type="text/css" rel="stylesheet" --}}
    {{-- <!-- image-gallery --> --}}
    <link href="{{ asset('assets/css/image-gallery.css') }}" rel="stylesheet" type="text/css" />

    <!-- owl carousal image gallery -->
    <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" />
    <!-- link for dots/arrow owl carousal -->
    <!-- <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css"
    /> -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.css" />

    <!--Google Fonts-->
    <link rel="preconnect" href="https://fonts.gstatic.com/" />
    <link
        href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,400;0,700;0,900;1,400;1,700;1,900&amp;family=Manrope:wght@300;400;600;800&amp;family=Volkhov:ital,wght@0,400;0,700;1,400;1,700&amp;display=swap"
        rel="stylesheet" />
    @yield('extracss')

    <style>

    </style>
</head>

<body>
    <div class="loader-backdrop">
        <!-- Loader -->
        <div class="loader">
            <i class="fa-solid fa-stethoscope"></i>
        </div>
    </div>
    <main>
        @yield('content')
    </main>



    <!-- JQuery Version 3.6.0 -->
    <script src="{{ asset('assets/js/jquery.min.js') }}"></script>

    <!-- jquery version 3.4.1 -->
    <script src="{{ asset('assets/js/jquery-3.4.1.min.js') }}"></script>

    <!-- new slick min.js  -->
    <script src="{{ asset('assets/js/slick.min.js') }}"></script>

    <!-- new jquery migrate  -->
    <script src="{{ asset('assets/js/jquery-migrate.js') }}"></script>

    <!-- new way points js -->
    <script src="{{ asset('assets/js/waypoints.min.js') }}"></script>

    <!-- new counter js -->
    <script src="{{ asset('assets/js/jQuery.rcounter.js') }}"></script>

    <!-- new  jquery nice-select-->
    <script src="{{ asset('assets/js/jquery.nice-select.min.js') }}"></script>

    <!-- new main -->
    <script src="{{ asset('assets/js/main.js') }}"></script>

    <!-- Bootstrap Version 4.5.3 -->
    <script src="{{ asset('assets/js/bootstrap.bundle.min.js') }}"></script>

    <!-- Appear JS -->
    <script src="{{ asset('assets/js/jquery.appear.min.js') }}"></script>

    <!--Pretty Photo Version 3.1.6-->
    <script src="{{ asset('assets/js/jquery.prettyPhoto.min.js') }}"></script>

    <!-- Count To JS -->
    <script src="{{ asset('assets/js/jquery.countTo.min.js') }}"></script>

    <!-- Slick Slider Version 1.8.1 -->
    <script src="{{ asset('assets/js/slick.min.js') }}"></script>

    <!-- jQuery UI (Date Picker) -->
    <script src="{{ asset('assets/js/jquery-ui.min.js') }}"></script>

    <!-- Custom JS -->
    <script src="{{ asset('assets/js/script.min.js') }}"></script>

    <!-- owl carousal image gallery -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.js"></script>

    <!-- WOW Aimation  -->
    <script src="{{ asset('assets/js/wow.min.js') }}"></script>


    @yield('scripts')
</body>

</html>
